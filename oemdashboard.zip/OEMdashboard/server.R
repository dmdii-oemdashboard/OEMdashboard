server <- function(input, output, session) {
  ####### Database authentication #######
  dataModal <- function(failed = FALSE) {
    modalDialog(
      textInput("username", "Please enter your name:"),
      passwordInput("password", "Password:"),
      if (failed)
        div(tags$b("Invalid username or password", style = "color: red;")),
      footer = tagList(
        modalButton("Cancel"),
        actionButton("ok", "OK")
      )
    )
  }
  
  observeEvent(input$db_confirm, {
    showModal(dataModal())
  })
  
  observeEvent(input$ok, {
    # Check that data object exists and is data frame.
    if (input$password == pwd) {
      removeModal()
      ### DB connection
      con <- dbConnect(MySQL(), user = user, password = password, dbname = dbname, host = host, port = port)
      db_tables <- dbListTables(con)
      ### Data retrieve
      query <- dbSendQuery(con, paste0("select * from podata;"))
      PO <<- fetch(query, n = -1)
      
      for (con in dbListConnections(MySQL())) {
        dbClearResult(query)
        dbDisconnect(con)
      }
        
      
      output$dt_choice <- renderUI({
        fluidRow(
          selectInput(inputId="tab_choice", label = "Please select table:", choices = db_tables),
          actionButton("table_view", "View"),
          actionButton("table_select", "Select")
        )
      })
      
      output$db_table <- DT::renderDataTable({
        datatable(PO[, input$var_all],
        options = list(scrollX = TRUE, autoWidth = TRUE))})
      
      observeEvent(input$table_view,{
        output$var <- renderUI({
          fluidRow(
            box(width = 4,
                selectizeInput('var_all', label = "Variables to show in the table below", choices = colnames(PO), multiple = TRUE, selected = colnames(PO))),
            box(width = 8,
                column(4,
                       selectizeInput('var_y', label = "Response Variable", choices = colnames(PO), selected = colnames(PO)[13]),
                       actionButton("y_select", 'Select')),
                column(8,
                       selectizeInput('var_x', label = "Predictor Variables", choices = colnames(PO), multiple = TRUE, selected = colnames(PO)[c(4,6,7,10,11,12,16)]),
                       actionButton("x_select", 'Select'))
            )
          )
        })
      })
      
      output$db_status1 <- renderText({
        paste0("You have selected: ", input$db_choice)
      })
      
      
    } else {
      showModal(dataModal(failed = TRUE))
    }
  })
  
  
  
  tab <- eventReactive(input$table_select,{
    input$tab_choice
  })

  output$table_status1 <- renderText({
    paste0("You have selected: ", tab())})

  x <- eventReactive(input$x_select,{
    input$var_x
  })
  output$x_status1 <- renderText({
    c("Predictor Variables: ", paste0(x(), collapse = ", "))
  })

  y <- eventReactive(input$y_select,{
    input$var_y
  })
  output$y_status1 <- renderText({
    paste0("Response variable: ", y())
  })

  output$status2 <- output$status3 <- output$status4 <- output$status5 <- output$status6 <- renderText({
    paste0("Current table in use: ",input$tab_choice, " from ", input$db_choice)
  })


  output$inoutput_status2 <- output$inoutput_status3 <- output$inoutput_status4 <- output$inoutput_status5 <- output$inoutput_status6 <- renderText({
    c("Predicting ",input$var_y, " using ", paste0(x(), collapse = ", ")," as predictors.")
  })




  observeEvent(input$train,{
    
    build <- Progress$new(session, min=1, max=20)
    build$set(message = 'Model training in progress',
              detail = 'This may take a while...')
    on.exit(build$close())
    for (i in 1:10) {
      build$set(value = i)
      Sys.sleep(0.5)
    }

    PO$ABC.Indicator <- as.factor(PO$ABC.Indicator)
    PO$Pdt <- as.numeric(as.character(PO$Pdt))
    PO$PO.Cycle.Time <- as.numeric(as.character(PO$PO.Cycle.Time))
    PO$Quantity <- as.character(PO$Quantity)
    PO$Quantity <- gsub(",", "", PO$Quantity)
    PO$Quantity <- as.numeric(PO$Quantity)
    PO <- PO[which(PO$Quantity > 0),]
    
    PO.open <- subset(PO, Open.PO == "Open PO", select = c("Purchasing.Document", "Item", "Vendor.Num", "Material.Number", "Plnt", "Material.Group",
                                                           "ABC.Indicator", "Pdt", "PO.Cycle.Time", "Purchase.Order.Date", "Delivery.Date", "Quantity"))
    PO.close <- subset(PO, Open.PO == "Closed PO", select = c("Purchasing.Document", "Item", "Vendor.Num", "Material.Number", "Plnt", "Material.Group",
                                                              "ABC.Indicator", "Pdt", "PO.Cycle.Time", "Purchase.Order.Date", "Delivery.Date", "Quantity"))
    #Change format to date
    PO.open$Purchase.Order.Date <- as.Date(PO.open$Purchase.Order.Date, format="%b %d, %Y", origin="1960-10-01")
    PO.open$Delivery.Date <- as.Date(PO.open$Delivery.Date, format="%b %d, %Y", origin="1960-10-01")
    
    
    
    if (input$parall == TRUE){
      ## change number of cores and total number of trees as desired
      core_no <- 4
      # create a cluster for parallelization
      cl <- makeCluster(core_no)
      registerDoParallel(cl)
      if (input$varselect == TRUE){
        level <- input$nlevel
        
        # Variable selection
        # Keep the top level Vendors
        Vendor.levels <- as.data.frame(sort(table(PO.close$Vendor.Num),decreasing=TRUE))
        colnames(Vendor.levels) <- c("Vendor.Num", "Freq")
        Vendor.bin <- PO.close$Vendor.Num %in% Vendor.levels$Vendor.Num[1:level]
        for (i in 1:length(PO.close$Vendor.Num)){
          if (Vendor.bin[i] == FALSE) {
            PO.close$Vendor.Num[i] <- "NULL"
          }
        }
        PO.close$Vendor.Num <- as.factor(PO.close$Vendor.Num)
        
        Vendor.bin <- PO.open$Vendor.Num %in% Vendor.levels$Vendor.Num[1:level]
        for (i in 1:length(PO.open$Vendor.Num)){
          if (Vendor.bin[i] == FALSE) {
            PO.open$Vendor.Num[i] <- "NULL"
          }
        }
        PO.open$Vendor.Num <- as.factor(PO.open$Vendor.Num)
        
        
        # Keep the top level MaterialNumber
        Vendor.levels <- as.data.frame(sort(table(PO.close$Material.Number),decreasing=TRUE))
        colnames(Vendor.levels) <- c("Material.Number", "Freq")
        Vendor.bin <- PO.close$Material.Number %in% Vendor.levels$Material.Number[1:level]
        for (i in 1:length(PO.close$Material.Number)){
          if (Vendor.bin[i] == FALSE) {
            PO.close$Material.Number[i] <- "NULL"
          }
        }
        PO.close$Material.Number <- as.factor(PO.close$Material.Number)
        
        Vendor.bin <- PO.open$Material.Number %in% Vendor.levels$Material.Number[1:level]
        for (i in 1:length(PO.open$Material.Number)){
          if (Vendor.bin[i] == FALSE) {
            PO.open$Material.Number[i] <- "NULL"
          }
        }
        PO.open$Material.Number <- as.factor(PO.open$Material.Number)
        
        # Keep the top level Plnt
        Vendor.levels <- as.data.frame(sort(table(PO.close$Plnt),decreasing=TRUE))
        colnames(Vendor.levels) <- c("Plnt", "Freq")
        Vendor.bin <- PO.close$Plnt %in% Vendor.levels$Plnt[1:level]
        for (i in 1:length(PO.close$Plnt)){
          if (Vendor.bin[i] == FALSE) {
            PO.close$Plnt[i] <- "NULL"
          }
        }
        PO.close$Plnt <- as.factor(PO.close$Plnt)
        
        Vendor.bin <- PO.open$Plnt %in% Vendor.levels$Plnt[1:level]
        for (i in 1:length(PO.open$Plnt)){
          if (Vendor.bin[i] == FALSE) {
            PO.open$Plnt[i] <- "NULL"
          }
        }
        PO.open$Plnt <- as.factor(PO.open$Plnt)
        
        # Keep the top level MaterialGroup
        Vendor.levels <- as.data.frame(sort(table(PO.close$Material.Group),decreasing=TRUE))
        colnames(Vendor.levels) <- c("Material.Group", "Freq")
        Vendor.bin <- PO.close$Material.Group %in% Vendor.levels$Material.Group[1:level]
        for (i in 1:length(PO.close$Material.Group)){
          if (Vendor.bin[i] == FALSE) {
            PO.close$Material.Group[i] <- "NULL"
          }
        }
        PO.close$Material.Group <- as.factor(PO.close$Material.Group)
        
        Vendor.bin <- PO.open$Material.Group %in% Vendor.levels$Material.Group[1:level]
        for (i in 1:length(PO.open$Material.Group)){
          if (Vendor.bin[i] == FALSE) {
            PO.open$Material.Group[i] <- "NULL"
          }
        }
        PO.open$Material.Group <- as.factor(PO.open$Material.Group)
        
        # # PCA
        # GE.sub <- subset(PO.close, select = c("Vendor.Num", "Plnt", "Material.Group"))
        # GE.dummy <- dummy.data.frame(GE.sub, dummy.classes = "ALL")
        # #fa.parallel(GE.dummy, fa="pc", n.iter=100)
        # PC <- principal(GE.dummy, nfactors = 5, rotate = 'varimax', scores = T)
        # PC$weights
        # summary(round(unclass(PC$weights),3)[,1])
        
        ytrain <- PO.close$PO.Cycle.Time
        xtrain <<- subset(PO.close, select = c("ABC.Indicator", "Pdt", "Quantity", "Plnt", "Material.Number", "Material.Group", "Vendor.Num"))
        xtest <<- subset(PO.open, select = c("ABC.Indicator", "Pdt", "Quantity", "Plnt", "Material.Number", "Material.Group", "Vendor.Num"))
        if (input$model == "Random Forest"){
          model <- foreach(ntree=rep(input$ntree/core_no,core_no),
                            .combine=combine, .multicombine=TRUE,
                            .packages="randomForest") %dopar% {
                              randomForest(PO.Cycle.Time~ABC.Indicator+Pdt+Quantity+Vendor.Num+Material.Group+Material.Number+Plnt,
                                           mtry = input$mtry, ntree = input$ntree, nodesize = input$nodesize, data = PO.close)}
          pred <- predict(model, PO.open)
        } else if (input$model == "Quantile Regression Forests"){
          ytrain <- PO.close$PO.Cycle.Time
          xtrain <- subset(PO.close, select = c("ABC.Indicator", "Pdt", "Quantity", "Plnt", "Material.Number", "Material.Group", "Vendor.Num"))
          xtest <- subset(PO.open, select = c("ABC.Indicator", "Pdt", "Quantity", "Plnt", "Material.Number", "Material.Group", "Vendor.Num"))

          model <- quantregForest(x = xtrain, y = ytrain , mtry = input$mtryq, ntree = input$ntreeq, nodesize = input$nodesizeq, nthreads = 4)
          
          common <- intersect(names(xtrain), names(xtest)) 
          for (p in common) { 
            if (class(xtrain[[p]]) == "factor") { 
              levels(xtest[[p]]) <- levels(xtrain[[p]]) 
            } 
          }

          pred <- predict(model, xtest, what = median)
          print("Done!!!!!!!")
        } else if (input$model == "Linear Regression"){
          model <- lm(PO.Cycle.Time~ABC.Indicator+Pdt+Quantity+Vendor.Num+Material.Group+Material.Number+Plnt, data = PO.close)
          pred <- predict(model, PO.open)
        }
      }else{
        if (input$model == "Random Forest"){
          model <- foreach(ntree=rep(input$ntree/core_no,core_no),
                           .combine=combine, .multicombine=TRUE,
                           .packages="randomForest") %dopar% {
                             randomForest(PO.Cycle.Time~ABC.Indicator+Pdt+Quantity,mtry = input$mtry, ntree = input$ntree, nodesize = input$nodesize, data = PO.close)
                           }
          pred <- predict(model, PO.open)
        } else if (input$model == "Quantile Regression Forests"){
          ytrain <- PO.close$PO.Cycle.Time
          xtrain <- subset(PO.close, select = c("ABC.Indicator", "Pdt", "Quantity"))
          xtest <- subset(PO.open, select = c("ABC.Indicator", "Pdt", "Quantity"))

          model <- quantregForest(x = xtrain, y = ytrain , mtry = input$mtryq, ntree = input$ntreeq, nodesize = input$nodesizeq, nthreads = 4)

          pred <- predict(model, xtest, what = median)
        } else if (input$model == "Linear Regression"){
          model <- lm(PO.Cycle.Time~ABC.Indicator+Pdt+Quantity, data = PO.close)
          pred <- predict(model, PO.open)
        }
      }
    }else{
      if (input$varselect == TRUE){
        level <- input$nlevel
        # Variable selection
        # Keep the top level Vendors
        Vendor.levels <- as.data.frame(sort(table(PO.close$Vendor.Num),decreasing=TRUE))
        colnames(Vendor.levels) <- c("Vendor.Num", "Freq")
        Vendor.bin <- PO.close$Vendor.Num %in% Vendor.levels$Vendor.Num[1:level]
        for (i in 1:length(PO.close$Vendor.Num)){
          if (Vendor.bin[i] == FALSE) {
            PO.close$Vendor.Num[i] <- "NULL"
          }
        }
        PO.close$Vendor.Num <- as.factor(PO.close$Vendor.Num)
        
        Vendor.bin <- PO.open$Vendor.Num %in% Vendor.levels$Vendor.Num[1:level]
        for (i in 1:length(PO.open$Vendor.Num)){
          if (Vendor.bin[i] == FALSE) {
            PO.open$Vendor.Num[i] <- "NULL"
          }
        }
        PO.open$Vendor.Num <- as.factor(PO.open$Vendor.Num)
        
        
        # Keep the top level MaterialNumber
        Vendor.levels <- as.data.frame(sort(table(PO.close$Material.Number),decreasing=TRUE))
        colnames(Vendor.levels) <- c("Material.Number", "Freq")
        Vendor.bin <- PO.close$Material.Number %in% Vendor.levels$Material.Number[1:level]
        for (i in 1:length(PO.close$Material.Number)){
          if (Vendor.bin[i] == FALSE) {
            PO.close$Material.Number[i] <- "NULL"
          }
        }
        PO.close$Material.Number <- as.factor(PO.close$Material.Number)
        
        Vendor.bin <- PO.open$Material.Number %in% Vendor.levels$Material.Number[1:level]
        for (i in 1:length(PO.open$Material.Number)){
          if (Vendor.bin[i] == FALSE) {
            PO.open$Material.Number[i] <- "NULL"
          }
        }
        PO.open$Material.Number <- as.factor(PO.open$Material.Number)
        
        # Keep the top level Plnt
        Vendor.levels <- as.data.frame(sort(table(PO.close$Plnt),decreasing=TRUE))
        colnames(Vendor.levels) <- c("Plnt", "Freq")
        Vendor.bin <- PO.close$Plnt %in% Vendor.levels$Plnt[1:level]
        for (i in 1:length(PO.close$Plnt)){
          if (Vendor.bin[i] == FALSE) {
            PO.close$Plnt[i] <- "NULL"
          }
        }
        PO.close$Plnt <- as.factor(PO.close$Plnt)
        
        Vendor.bin <- PO.open$Plnt %in% Vendor.levels$Plnt[1:level]
        for (i in 1:length(PO.open$Plnt)){
          if (Vendor.bin[i] == FALSE) {
            PO.open$Plnt[i] <- "NULL"
          }
        }
        PO.open$Plnt <- as.factor(PO.open$Plnt)
        
        # Keep the top level MaterialGroup
        Vendor.levels <- as.data.frame(sort(table(PO.close$Material.Group),decreasing=TRUE))
        colnames(Vendor.levels) <- c("Material.Group", "Freq")
        Vendor.bin <- PO.close$Material.Group %in% Vendor.levels$Material.Group[1:level]
        for (i in 1:length(PO.close$Material.Group)){
          if (Vendor.bin[i] == FALSE) {
            PO.close$Material.Group[i] <- "NULL"
          }
        }
        PO.close$Material.Group <- as.factor(PO.close$Material.Group)
        
        Vendor.bin <- PO.open$Material.Group %in% Vendor.levels$Material.Group[1:level]
        for (i in 1:length(PO.open$Material.Group)){
          if (Vendor.bin[i] == FALSE) {
            PO.open$Material.Group[i] <- "NULL"
          }
        }
        PO.open$Material.Group <- as.factor(PO.open$Material.Group)
        
        # # PCA
        # GE.sub <- subset(PO.close, select = c("Vendor.Num", "Plnt", "Material.Group"))
        # GE.dummy <- dummy.data.frame(GE.sub, dummy.classes = "ALL")
        # #fa.parallel(GE.dummy, fa="pc", n.iter=100)
        # PC <- principal(GE.dummy, nfactors = 5, rotate = 'varimax', scores = T)
        # PC$weights
        # summary(round(unclass(PC$weights),3)[,1])
        
        ytrain <- PO.close$PO.Cycle.Time
        xtrain <<- subset(PO.close, select = c("ABC.Indicator", "Pdt", "Quantity", "Plnt", "Material.Number", "Material.Group", "Vendor.Num"))
        xtest <<- subset(PO.open, select = c("ABC.Indicator", "Pdt", "Quantity", "Plnt", "Material.Number", "Material.Group", "Vendor.Num"))
          if (input$model == "Random Forest"){
            model <- randomForest(PO.Cycle.Time~ABC.Indicator+Pdt+Quantity+Vendor.Num+Material.Group+Material.Number+Plnt,
                                  mtry = input$mtry, ntree = input$ntree, nodesize = input$nodesize, data = PO.close)
            pred <- predict(model, PO.open)
          } else if (input$model == "Quantile Regression Forests"){
            ytrain <- PO.close$PO.Cycle.Time
            xtrain <- subset(PO.close, select = c("ABC.Indicator", "Pdt", "Quantity", "Plnt", "Material.Number", "Material.Group", "Vendor.Num"))
            xtest <- subset(PO.open, select = c("ABC.Indicator", "Pdt", "Quantity", "Plnt", "Material.Number", "Material.Group", "Vendor.Num"))

            model <- quantregForest(x = xtrain, y = ytrain , mtry = input$mtryq, ntree = input$ntreeq, nodesize = input$nodesizeq, nthreads = 1)

            pred <- predict(model, xtest, what = median)
          } else if (input$model == "Linear Regression"){
            model <- lm(PO.Cycle.Time~ABC.Indicator+Pdt+Quantity+Vendor.Num+Material.Group+Material.Number+Plnt, data = PO.close)
            pred <- predict(model, PO.open)
          }
      }else{
        if (input$model == "Random Forest"){
          model <- randomForest(PO.Cycle.Time~ABC.Indicator+Pdt+Quantity,
                                mtry = input$mtry, ntree = input$ntree, nodesize = input$nodesize, data = PO.close)
          pred <- predict(model, PO.open)
        } else if (input$model == "Quantile Regression Forests"){
          ytrain <- PO.close$PO.Cycle.Time
          xtrain <- subset(PO.close, select = c("ABC.Indicator", "Pdt", "Quantity"))
          xtest <- subset(PO.open, select = c("ABC.Indicator", "Pdt", "Quantity"))

          model <- quantregForest(x = xtrain, y = ytrain , mtry = input$mtryq, ntree = input$ntreeq, nodesize = input$nodesizeq, nthreads = 1)

          pred <- predict(model, xtest, what = median)
        } else if (input$model == "Linear Regression"){
          model <- lm(PO.Cycle.Time~ABC.Indicator+Pdt+Quantity, data = PO.close)
          pred <- predict(model, PO.open)
        }
      }
    }
    
    #Naming and reordering columns for the table
    if (input$model == "Linear Regression"){
      PO.close <- cbind(PO.close, model$fitted.values)
    } else {
      PO.close <- cbind(PO.close, model$predicted)
    }

    PO.open <- cbind(PO.open, pred)
    colnames(PO.close) <- c("Purchasing Document", "Item", "Vendor Number", "Material Number", "Plant ID", "Material Group", "ABC Indicator",
                            "Planned Delivery Time","Actual Delivery Time", "Purchase Order Date", "Delivery Date", "Quantity",
                            "Predicted Delivery Time")
    colnames(PO.open) <- c("Purchasing Document", "Item", "Vendor Number", "Material Number", "Plant ID", "Material Group", "ABC Indicator",
                           "Planned Delivery Time","Actual Delivery Time", "Purchase Order Date", "Delivery Date", "Quantity",
                           "Predicted Delivery Time")
    PO.open <-  PO.open[,-c(9,11)]
    
    difference <- PO.open$`Predicted Delivery Time` - PO.open$`Planned Delivery Time`
    PO.open$`Delay Risks` <- difference
    difference[difference >= 20] <- 20
    difference[difference <= -20] <- -20
  
    for (i in 11:20) {
      build$set(value = i)
      Sys.sleep(0.5)
    }

  observeEvent(input$train,{
    

    output$model_status2 <- output$model_status3 <- output$model_status4 <- output$model_status5 <- output$model_status6 <- renderText({
      if (input$varselect == TRUE){
        if (input$parall == TRUE){
          paste0("Current model in use: ",input$model, " with variable selection in parallel training mode.")
        }else{
          paste0("Current model in use: ",input$model, " with variable selection in sequential training mode.")
        }
      }else{
        if (input$parall){
          paste0("Current model in use: ",input$model, " without variable selection in parallel training mode.")
        }else{
          paste0("Current model in use: ",input$model, " without variable selection in sequential training mode.")
        }
      }
    })
  })

  output$OpenOrdersTable = DT::renderDataTable({
    if (input$dt_select == "Closed POs"){
      datatable(PO.close, filter = "top", options = list(scrollX = TRUE, autoWidth = TRUE, search = list(regex = TRUE)))
    }else if (input$dt_select == "Open POs"){
      datatable(PO.open, filter = "top", options = list(scrollX = TRUE, autoWidth = TRUE, search = list(regex = TRUE))) %>% formatStyle("Delay Risks",
                                                                                                                                        background = color_from_middle(difference, 'skyblue', "pink"),
                                                                                                                                        backgroundSize = '98% 70%',
                                                                                                                                        backgroundRepeat = 'no-repeat',
                                                                                                                                        backgroundPosition = 'center',
                                                                                                                                        textAlign = 'center')
    }
  })

  output$od_barchart = renderPlotly({
    if (input$bar_x == "Purchase Order Date" & input$bar_y == "Number of Open Orders"){
      ge.od.bar <- as.data.frame(table(PO.open$`Purchase Order Date`))
      colnames(ge.od.bar) <- c("OrderDate", "NumberofOrders")
      ge.od.bar$OrderDate <- as.Date(ge.od.bar$OrderDate)
    } else if (input$bar_x == "Purchase Order Date" & input$bar_y == "Number of Delay Risk Orders"){
      ge.od.bar <- as.data.frame(table(PO.open$`Purchase Order Date`[PO.open$`Delay Risks`>=0]))
      colnames(ge.od.bar) <- c("OrderDate", "NumberofOrders")
      ge.od.bar$OrderDate <- as.Date(ge.od.bar$OrderDate)
    } else if (input$bar_x == "Purchase Order Date" & input$bar_y == "Number of Expected Early Orders"){
      ge.od.bar <- as.data.frame(table(PO.open$`Purchase Order Date`[PO.open$`Delay Risks`<=0]))
      colnames(ge.od.bar) <- c("OrderDate", "NumberofOrders")
      ge.od.bar$OrderDate <- as.Date(ge.od.bar$OrderDate)
    } else if (input$bar_x == "Planned Delivery Date" & input$bar_y == "Number of Open Orders"){
      ge.od.bar <- as.data.frame(table(PO.open$`Purchase Order Date`+PO.open$`Planned Delivery Time`))
      colnames(ge.od.bar) <- c("OrderDate", "NumberofOrders")
      ge.od.bar$OrderDate <- as.Date(ge.od.bar$OrderDate)
    } else if (input$bar_x == "Planned Delivery Date" & input$bar_y == "Number of Delay Risk Orders"){
      ge.od.bar <- as.data.frame(table((PO.open$`Purchase Order Date`+PO.open$`Planned Delivery Time`)[PO.open$`Delay Risks`>=0]))
      colnames(ge.od.bar) <- c("OrderDate", "NumberofOrders")
      ge.od.bar$OrderDate <- as.Date(ge.od.bar$OrderDate)
    } else if (input$bar_x == "Planned Delivery Date" & input$bar_y == "Number of Expected Early Orders"){
      ge.od.bar <- as.data.frame(table((PO.open$`Purchase Order Date`+PO.open$`Planned Delivery Time`)[PO.open$`Delay Risks`<=0]))
      colnames(ge.od.bar) <- c("OrderDate", "NumberofOrders")
      ge.od.bar$OrderDate <- as.Date(ge.od.bar$OrderDate)
    } else if (input$bar_x == "Predicted Delivery Date" & input$bar_y == "Number of Open Orders"){
      ge.od.bar <- as.data.frame(table(PO.open$`Purchase Order Date`+PO.open$`Predicted Delivery Time`))
      colnames(ge.od.bar) <- c("OrderDate", "NumberofOrders")
      ge.od.bar$OrderDate <- as.Date(ge.od.bar$OrderDate)
    } else if (input$bar_x == "Predicted Delivery Date" & input$bar_y == "Number of Delay Risk Orders"){
      ge.od.bar <- as.data.frame(table((PO.open$`Purchase Order Date`+PO.open$`Predicted Delivery Time`)[PO.open$`Delay Risks`>=0]))
      colnames(ge.od.bar) <- c("OrderDate", "NumberofOrders")
      ge.od.bar$OrderDate <- as.Date(ge.od.bar$OrderDate)
    } else if (input$bar_x == "Predicted Delivery Date" & input$bar_y == "Number of Expected Early Orders"){
      ge.od.bar <- as.data.frame(table((PO.open$`Purchase Order Date`+PO.open$`Predicted Delivery Time`)[PO.open$`Delay Risks`<=0]))
      colnames(ge.od.bar) <- c("OrderDate", "NumberofOrders")
      ge.od.bar$OrderDate <- as.Date(ge.od.bar$OrderDate)
    }
    
    
    start.date <- input$purchase_date[1]
    end.date <- input$purchase_date[2]
    ge.tmp <- ge.od.bar[ge.od.bar$OrderDate >= start.date,]
    ge.tmp <- ge.tmp[ge.tmp$OrderDate <= end.date,]

    od_bar <- plot_ly(ge.tmp) %>%
      add_trace(x = ~OrderDate, y = ~NumberofOrders, type = 'bar', hoverinfo = 'text', marker=list(color="skyblue"),
                text = ~paste(input$bar_x,': ',OrderDate,'\n',input$bar_y,': ',NumberofOrders)) %>%
      layout(margin = list(b = 70), xaxis= list(title = input$bar_x),
             yaxis = list(title = input$bar_y),
             showlegend = FALSE) %>% onRender(bar)
  })

  output$od_click <- DT::renderDataTable({
    d <- event_data("plotly_click")
    if (is.null(d)) NULL else {
      tmp <- as.Date(as.list(d)$x)
      
      if (input$bar_x == "Purchase Order Date" & input$bar_y == "Number of Open Orders"){
        vis <- PO.open[PO.open$`Purchase Order Date` == tmp,]
      } else if (input$bar_x == "Purchase Order Date" & input$bar_y == "Number of Delay Risk Orders"){
        vis <- PO.open[PO.open$`Purchase Order Date` == tmp & PO.open$`Delay Risks`>=0,]
      } else if (input$bar_x == "Purchase Order Date" & input$bar_y == "Number of Expected Early Orders"){
        vis <- PO.open[PO.open$`Purchase Order Date` == tmp & PO.open$`Delay Risks`<=0,]
      } else if (input$bar_x == "Planned Delivery Date" & input$bar_y == "Number of Open Orders"){
        vis <- PO.open[(PO.open$`Purchase Order Date`+PO.open$`Planned Delivery Time` )== tmp,]
      } else if (input$bar_x == "Planned Delivery Date" & input$bar_y == "Number of Delay Risk Orders"){
        vis <- PO.open[(PO.open$`Purchase Order Date`+PO.open$`Planned Delivery Time` ) == tmp & PO.open$`Delay Risks`>=0,]
      } else if (input$bar_x == "Planned Delivery Date" & input$bar_y == "Number of Expected Early Orders"){
        vis <- PO.open[(PO.open$`Purchase Order Date`+PO.open$`Planned Delivery Time` ) == tmp & PO.open$`Delay Risks`<=0,]
      } else if (input$bar_x == "Predicted Delivery Date" & input$bar_y == "Number of Open Orders"){
        vis <- PO.open[(PO.open$`Purchase Order Date`+PO.open$`Predicted Delivery Time` )== tmp,]
      } else if (input$bar_x == "Predicted Delivery Date" & input$bar_y == "Number of Delay Risk Orders"){
        vis <- PO.open[(PO.open$`Purchase Order Date`+PO.open$`Predicted Delivery Time` ) == tmp & PO.open$`Delay Risks`>=0,]
      } else if (input$bar_x == "Predicted Delivery Date" & input$bar_y == "Number of Expected Early Orders"){
        vis <- PO.open[(PO.open$`Purchase Order Date`+PO.open$`Predicted Delivery Time` ) == tmp & PO.open$`Delay Risks`<=0,]
      }
      
      
      datatable(vis, filter = "top", options = list(scrollX = TRUE, autoWidth = TRUE, search = list(regex = TRUE))) %>% formatStyle("Delay Risks",
                                                                                                                                                                               background = color_from_middle(difference, 'skyblue', "pink"),
                                                                                                                                                                               backgroundSize = '98% 70%',
                                                                                                                                                                               backgroundRepeat = 'no-repeat',
                                                                                                                                                                               backgroundPosition = 'center',
                                                                                                                                                                               textAlign = 'center')
    }
  }, options = list(scrollX = TRUE, autoWidth = TRUE))

  output$risk_scatter <- renderPlotly({
    if (input$scatter_x == "Planned Delivery Date"){
      PO.open$pdd <- PO.open$`Purchase Order Date` + PO.open$`Planned Delivery Time`
    } else if (input$scatter_x == "Purchase Order Date"){
      PO.open$pdd <- PO.open$`Purchase Order Date`
    } else if (input$scatter_x == "Predicted Delivery Date"){
      PO.open$pdd <- PO.open$`Purchase Order Date` + PO.open$`Predicted Delivery Time`
    }
    

    start.date <- input$risk_range[1]
    end.date <- input$risk_range[2]

    PO.tmp <<- PO.open[PO.open$pdd <= end.date,]
    PO.tmp <<- PO.tmp[PO.tmp$pdd >= start.date,]


    plot_ly(PO.tmp) %>%
      add_trace(x=~pdd, y=~`Delay Risks`, type = "scatter", hoverinfo = 'text', marker = list(color="skyblue"),
                text = ~paste('Vendor Number: ',`Vendor Number`,'\n','Material Number: ',`Material Number`,'\n',
                              'Plant ID: ',`Plant ID`,'\n','Material Group: ',`Material Group`,'\n','Planned Delivery Time: ',
                              `Planned Delivery Time`,'\n',
                              'Purchase Order Date: ',`Purchase Order Date`,'\n','Quantity: ',`Quantity`,'\n',
                              'Predicted Delivery Time: ', `Predicted Delivery Time`,'\n','Predicted Delay in days: ',
                              `Delay Risks`)) %>%
      layout(margin = list(b = 70), xaxis= list(title = input$scatter_x),
             yaxis = list(title = 'Predicted PO Delay'),
             showlegend = FALSE,dragmode = "select") %>% onRender(scatter)
  })

  output$scatter_brush <- DT::renderDataTable({
    d <- event_data("plotly_selected")
    if(is.null(d) == T) return(NULL)
    else {
      PO.tmp <- subset(PO.tmp)[subset(d, curveNumber == 0)$pointNumber + 1,-13]
      PO.tmp <- as.data.frame(PO.tmp)
      datatable(PO.tmp,
                filter = "top", options = list(scrollX = TRUE, autoWidth = TRUE,
                                               search = list(regex = TRUE))) %>%
        formatStyle("Delay Risks",
                    background = color_from_middle(difference, 'skyblue', "pink"),
                    backgroundSize = '98% 70%',
                    backgroundRepeat = 'no-repeat',
                    backgroundPosition = 'center',
                    textAlign = 'center')
    }
  })

  #Prediction tab
  output$pre_tab <- renderUI({
    fluidPage(
      box(width = "100%",
          h3(textOutput("status6")),
          h3(textOutput("inoutput_status6")),
          h3(textOutput("model_status6"))),
      valueBoxOutput("lowerPrediction"),
      valueBoxOutput("actualPrediction"),
      valueBoxOutput("upperPrediction"),
      box(
        column(6,
               selectInput(inputId = "predictABC", label = "ABC Indicator", choices = sort(levels(xtrain$ABC.Indicator)), selected = "A"),
               numericInput(inputId = "predictQuantity", label = "Quantity:", value = 10),
               numericInput(inputId = "predictPdt", label = "Planned delivery time (in days):", value = 40),
               actionButton(inputId = "pre_train", label = "Predict")
        ),
        column(6,
               conditionalPanel(condition = "input.varselect == true",
                                selectInput(inputId = "predictVendor", label = "Vendor Number", choices = sort(levels(xtrain$Vendor.Num))),
                                selectInput(inputId = "predictPlant", label = "Plant ID:", choices = sort(levels(xtrain$Plnt))),
                                selectInput(inputId = "predictMaterialGroup", label = "Material Group", choices = sort(levels(xtrain$Material.Group))),
                                selectInput(inputId = "predictMaterialNumber", label = "Material Number", choices = sort(levels(xtrain$Material.Number)))
               )
        )
      )
    )
    
  })
  
  observeEvent(input$pre_train, {
    if (input$varselect == TRUE){
      pre <- xtrain[0,]
      pre[1,7] <- factor(input$predictVendor, levels = levels(xtrain$Vendor))
      pre[1,5] <- factor(input$predictMaterialNumber, levels = levels(xtrain$Material.Number))
      pre[1,4] <- factor(input$predictPlant, levels = levels(xtrain$Plnt))
      pre[1,6] <- factor(input$predictMaterialGroup, levels = levels(xtrain$Material.Group))
      pre[1,1] <- factor(input$predictABC, levels = levels(xtrain$ABC.Indicator))
      pre[1,2] <- input$predictPdt
      pre[1,3] <- input$predictQuantity
      pre <- as.data.frame(pre)
      tmp1 <- predict(model, newdata = pre, what = c(0.1, 0.5, 0.9))
      pred.u <- round(tmp1[1,3], digits = 1)
      pred.m <- round(tmp1[1,2], digits = 1)
      pred.l <- round(tmp1[1,1], digits = 1)
    }else{
      pre <- xtrain[0,c(1:3)]
      pre[1,1] <- factor(input$predictABC, levels = levels(xtrain$ABC.Indicator))
      pre[1,2] <- input$predictPdt
      pre[1,3] <- input$predictQuantity
      tmp1 <- predict(model, newdata = pre, what = c(0.1, 0.5, 0.9))
      pred.u <- round(tmp1[1,3]+runif(1, 0, 0.5), digits = 1)
      pred.m <- round(tmp1[1,2]+runif(1, 0, 0.5), digits = 1)
      pred.l <- round(tmp1[1,1]+runif(1, 0, 0.5), digits = 1)
    }

    output$lowerPrediction <- renderValueBox({
      valueBox(
        paste0(pred.l), "Lower Prediction Interval", icon = icon("list"),
        color = "purple"
      )
    })

    output$actualPrediction <- renderValueBox({
      valueBox(
        paste0(pred.m), "Predicted Delivery Days", icon = icon("list"),
        color = "purple"
      )
    })

    output$upperPrediction <- renderValueBox({
      valueBox(
        paste0(pred.u), "Upper Prediction Interval", icon = icon("list"),
        color = "purple"
      )
    })

  })
  })
  }