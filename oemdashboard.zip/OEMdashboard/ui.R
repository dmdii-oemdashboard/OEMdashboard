notifications <- dropdownMenu(type = "notifications",
                              notificationItem(
                                status="warning",
                                text = "Data updated 3/19/2018",
                                icon("info-circle")
                              )
)

# Header menu
header <- dashboardHeader(title = "OEM Supply Chain Visibility Dashboard",titleWidth = 370, notifications)

# Sidebar menu
sidebar <- dashboardSidebar(
  sidebarMenu(
    menuItem("Database Access", tabName = "database", icon = icon("database")),
    menuItem("Prediction Model Training", tabName = "training", icon = icon("cubes")),
    menuItem("Current Predictions", tabName = "result", icon = icon("bar-chart"),
             menuItem("Delivery Time Predictions", tabName = "bar", icon = icon("bar-chart")),
             menuItem("Delay Risk Identification", tabName = "scatter", icon = icon("line-chart")),
             menuItem("Tabular", tabName = "table", icon = icon("table"))),
    menuItem("Future Predictions", tabName = "predictions", icon = icon("info-circle"))
  )
)

# Body
body <- dashboardBody(
  tabItems(
    ################# Database Access Tab ####################
    tabItem(
      tabName = "database",
      fluidRow(
        box(width = "100%",
            h3(textOutput("db_status1")),
            h3(textOutput("table_status1")),
            h3(textOutput("x_status1")),
            h3(textOutput("y_status1"))),
        box(width = "100%",
            column(6,
                   selectInput(inputId = "db_choice", label = 'Please choose the database:', choices = dbname),
                   actionButton(inputId = "db_confirm", label = "Confirm")),
            column(6,
                   uiOutput("dt_choice")
            )),
        box(width = "100%",
            uiOutput("var")
            )
      ),
      fluidRow(box(width = "100%",
                   DT::dataTableOutput('db_table')))
      
    ),
    ############### Model Training ################
    tabItem(
      tabName = "training",
      box(width = "100%",
          h3(textOutput("status2")),
          h3(textOutput("inoutput_status2")),
          h3(textOutput("model_status2"))),
      fluidRow(
        box(width = "100%",
            column(4,
                   selectInput(inputId = "model", label = "Training model to use:", choices = c("Linear Regression", "Random Forest", "Quantile Regression Forests"),selected = "Quantile Regression Forests"),
                   checkboxInput(inputId = "varselect", label = "Using variable selection method", TRUE),
                   checkboxInput(inputId = "parall", label = "Using parallel training mode", TRUE),
                   actionButton(inputId = "train", label = "Build the model")
            ),
            column(4,
                   conditionalPanel(condition = "input.model == 'Random Forest'",
                                    numericInput(inputId = "ntree", label = "Number of Trees", value = 120, min = 10, max = 500, step = 10),
                                    numericInput(inputId = "mtry", label = "Number of Variables sampled at each split", value = 2, min = 1, max = 10, step = 1),
                                    numericInput(inputId = "nodesize", label = "Minimum size of terminal nodes", value = 5, min = 1, max = 100, step = 1)
                   ),
                   conditionalPanel(condition = "input.model == 'Quantile Regression Forests'",
                                    numericInput(inputId = "ntreeq", label = "Number of Trees", value = 120, min = 10, max = 500, step = 10),
                                    numericInput(inputId = "mtryq", label = "Number of Variables sampled at each split", value = 2, min = 1, max = 10, step = 1),
                                    numericInput(inputId = "nodesizeq", label = "Minimum size of terminal nodes", value = 5, min = 1, max = 100, step = 1)
                   )
            ),
            column(4,
                   conditionalPanel(condition = "input.varselect == true",
                                    numericInput(inputId = "npc", label = "Number of PCs", value = 5, min = 5, max = 50, step = 1),
                                    numericInput(inputId = "nlevel", label = "Number of Levels kept in categorical variables", value = 15, min = 5, max = 1000, step = 1)
                   )
            )
        ))
    ),
    ################## Result Visualization Tab ##############
    tabItem(tabName = "bar",
            box(width = "100%",
                h3(textOutput("status3")),
                h3(textOutput("inoutput_status3")),
                h3(textOutput("model_status3"))),
            box(title = "Bar Chart for Open Orders", plotlyOutput(outputId = "od_barchart"), width = "100%"),
            box(width = "100%", 
                column(4,
                       dateRangeInput("purchase_date", 'Please select the date range: ',
                                      start  = "2016-12-15",
                                      end    = "2017-04-24",
                                      min    = "2016-04-25",
                                      max    = "2017-04-24",
                                      separator = " - ")),
                column(4,
                       selectizeInput("bar_x", "Please select X-axis for the bar plot: ", choices=c("Purchase Order Date", "Planned Delivery Date", "Predicted Delivery Date"), selected = "Purchase Order Date")),
                column(4,
                       selectizeInput("bar_y", "Please select Y-axis for the bar plot: ", choices=c("Number of Open Orders","Number of Delay Risk Orders", "Number of Expected Early Orders"), selected = "Number of Open Orders"))
               ),
            box(title = "You select (by clicking):", DT::dataTableOutput('od_click'), width = "100%" , height = "100%")
    ),
    tabItem(tabName = "scatter",
            box(width = "100%",
                h3(textOutput("status4")),
                h3(textOutput("inoutput_status4")),
                h3(textOutput("model_status4"))),
            fluidRow(box(plotlyOutput(outputId = "risk_scatter"), width = "100%", height = "100%")),
            box(width = "100%",
                column(6,
                       dateRangeInput("risk_range", 'Please select the date range: ',
                                      start  = "2016-12-15",
                                      end    = "2017-04-24",
                                      min    = "2016-04-25",
                                      max    = "2017-04-24",
                                      separator = " - ")),
                column(6,
                       selectizeInput("scatter_x", "Please select X-axis for the scatter plot: ", choices=c("Planned Delivery Date","Purchase Order Date", "Predicted Delivery Date"), selected = "Planned Delivery Date"))),
            fluidRow(box(DT::dataTableOutput('scatter_brush'), width = "100%" , height = "100%"))
    ),
    tabItem(tabName = "table",
            box(width = "100%",
                h3(textOutput("status5")),
                h3(textOutput("inoutput_status5")),
                h3(textOutput("model_status5"))),
            box(selectInput(inputId = "dt_select", label = "Table to display", choices = c("Closed POs", "Open POs"))),
            box(DT::dataTableOutput('OpenOrdersTable'), width = "100%" , height = "100%")),
    tabItem(tabName = "predictions",
            uiOutput("pre_tab")
    )
  )
)
dashboardPage(header, sidebar, body, skin = "purple")