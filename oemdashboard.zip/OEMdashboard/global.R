library(shiny)
library(shinydashboard)
library(plotly)
library(randomForest)
library(quantregForest)
library(dplyr)
library(DT)
library(htmlwidgets)
library(RMySQL)
library(lubridate)
library(doParallel)
library(shinycssloaders)
library(caret)
library(shinyjs)
library(dummies)

pwd <- "test" # password for system login

#### Database connection parameters, please change this part to specify your connection
user = "root"
password = "Dwyanewade520!"
dbname = "PO"
host = '127.0.0.1'
port = 3306


### Javascript function of changing the color of the bar chart. Please do not change codes from this point without specifically needs ###
bar <- "
  function(el, x){
    el.on('plotly_click', function(data){
      colors = [];
      var base_color = document.getElementsByClassName('point')[data.points[0].curveNumber].getElementsByTagName('path')[0].style['fill']
      for (var i = 0; i < data.points[0].data.x.length; i += 1) {
        colors.push(base_color)
      };
      colors[data.points[0].pointNumber] = 'SlateBlue';
      Plotly.restyle(el,{'marker':{color: colors}}, [data.points[0].curveNumber]);
    
      //make sure all the other traces get back their original color
      for (i = 0; i < document.getElementsByClassName('plotly')[0].data.length; i += 1) {
        if (i != data.points[0].curveNumber) {
          colors = [];
          base_color = document.getElementsByClassName('legendpoints')[i].getElementsByTagName('path')[0].style['stroke'];
          for (var p = 0; p < document.getElementsByClassName('plotly')[0].data[i].x.length; p += 1) {
            colors.push(base_color);
          }
          Plotly.restyle(el,{'marker':{color: colors}},[i]);
        }
      };
    });
  }"

### function of changing the color of the scatter plot ###
scatter <- "
  function(el, x){
    el.on('plotly_click', function(data){
      colors = [];
      var base_color = document.getElementsByClassName('points')[data.points[0].curveNumber].getElementsByTagName('path')[0].style['fill']
      for (var i = 0; i < data.points[0].data.x.length; i += 1) {
        colors.push(base_color)
      };
      colors[data.points[0].pointNumber] = 'SlateBlue';
      Plotly.restyle(el,{'marker':{color: colors}}, [data.points[0].curveNumber]);

      //make sure all the other traces get back their original color
      for (i = 0; i < document.getElementsByClassName('plotly')[0].data.length; i += 1) {
        if (i != data.points[0].curveNumber) {
          colors = [];
          base_color = document.getElementsByClassName('legendpoints')[i].getElementsByTagName('path')[0].style['stroke'];
          for (var p = 0; p < document.getElementsByClassName('plotly')[0].data[i].x.length; p += 1) {
            colors.push(base_color);
          }
          Plotly.restyle(el,{'marker':{color: colors}}, [i]);
        }
      };
    });
  }"

### Visualization function
color_from_middle <- function (data, color1,color2) {
  max_val=max(abs(data))
  JS(sprintf("isNaN(parseFloat(value)) || value < 0 ? 'linear-gradient(90deg, transparent, transparent ' + (50 + value/%s * 50) + '%%, %s ' + (50 + value/%s * 50) + '%%,%s  50%%,transparent 50%%)': 'linear-gradient(90deg, transparent, transparent 50%%, %s 50%%, %s ' + (50 + value/%s * 50) + '%%, transparent ' + (50 + value/%s * 50) + '%%)'",
             max_val,color1,max_val,color1,color2,color2,max_val,max_val))
}
